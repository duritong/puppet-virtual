class Puppet::Network::Client::File < Puppet::Network::Client::ProxyClient
    @handler = Puppet::Network::Handler.handler(:fileserver)
    @drivername = :FileServer
    self.mkmethods
end

# $Id: file.rb 2259 2007-03-06 19:03:05Z luke $

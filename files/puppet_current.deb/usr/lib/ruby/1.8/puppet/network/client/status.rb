class Puppet::Network::Client::Status < Puppet::Network::Client::ProxyClient
    self.mkmethods
end

# $Id: status.rb 2259 2007-03-06 19:03:05Z luke $

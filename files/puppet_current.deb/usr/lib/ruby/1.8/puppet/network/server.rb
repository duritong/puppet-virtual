# Just a stub, so we can correctly scope other classes.
module Puppet::Network::Server # :nodoc:
end

# $Id: server.rb 2259 2007-03-06 19:03:05Z luke $

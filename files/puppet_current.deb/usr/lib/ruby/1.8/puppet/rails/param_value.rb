class Puppet::Rails::ParamValue < ActiveRecord::Base
    belongs_to :param_name
    belongs_to :resource
end

# $Id: param_value.rb 2565 2007-06-12 00:31:16Z ballman $
